import React, { useState, useEffect } from 'react';

export default function App() {
  const [typedText, setTypedText] = useState('');
  const fullText = 'Olá, eu sou o Yuri. Desenvolvedor Web.';

  useEffect(() => {
    let i = 0;
    const interval = setInterval(() => {
      setTypedText(fullText.slice(0, i + 1));
      i++;
      if (i === fullText.length) clearInterval(interval);
    }, 100);
    return () => clearInterval(interval);
  }, []);

  const [projects, setProjects] = useState([]);
  useEffect(() => {
    setProjects([
      { id: 1, name: 'Projeto 1', desc: 'Descrição do Projeto 1' },
      { id: 2, name: 'Projeto 2', desc: 'Descrição do Projeto 2' }
    ]);
  }, []);

  return (
    <div className="container py-5">
      <h1>{typedText}</h1>
      <section className="mt-5">
        <h2>Projetos</h2>
        <div className="row">
          {projects.map((proj) => (
            <div className="col-md-6 mb-3" key={proj.id}>
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">{proj.name}</h5>
                  <p className="card-text">{proj.desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}